#include <stdio.h>
#ifdef _IPP
	#include <mathimf.h>
#else
	#include <math.h>
#endif
#include <stdlib.h>
#include <float.h>
#include <iostream>
using namespace std;
#include "share.h"

extern INTERVAL intvl[2], intvlTail[2];

// encode one source symbol
void encode_symbol(unsigned *str, unsigned &low, unsigned &high, int &nuf, int &ptr, byte x, bool isTail){
	if(isTail){
		if(x) low += unsigned(ceil((high-low)*intvlTail[1].l + intvlTail[1].l));
		else  high = low + unsigned(ceil((high-low)*intvlTail[0].h + intvlTail[0].h)) - 1;
	}else{
		if(x) low += unsigned(ceil((high-low)*intvl[1].l + intvl[1].l));
		else  high = low + unsigned(ceil((high-low)*intvl[0].h + intvl[0].h)) - 1;
	}

	/* If this test passes, it means that the MSDigits match, and can be sent to the output stream. */
	byte msbl = _bittest((const long*)&low, ACBITS-1);
	byte msbh = _bittest((const long*)&high, ACBITS-1);
	if(msbl==msbh){
		putbit((long*)str, ptr, msbl); ptr++;
		low  <<= 1;
		high <<= 1;	high |= 1;
		while(nuf){
			putbit((long*)str, ptr, !msbl); ptr++;
			nuf--;
		}
		while(_bittest((const long*)&high, ACBITS-1) == _bittest((const long*)&low, ACBITS-1)){
			putbit((long*)str, ptr, _bittest((const long*)&low, ACBITS-1)); ptr++;
			low  <<= 1;
			high <<= 1;	high |= 1;
		}
		low &= MASK; high &= MASK;
	}

	/* If this test passes, the numbers are in danger of underflow, because the MSDigits don't match, and the 2nd digits are just one apart. */
	while(!_bittest((const long*)&high, ACBITS-2) && _bittest((const long*)&low, ACBITS-2)){	
		low  -= QRANGE;	low  <<= 1;
		high -= QRANGE;	high <<= 1;	high |= 1;
		nuf++;
	}
}

// str <= src
int compress(unsigned *str, unsigned *src, int N, int T){
	unsigned low = 0, high = MASK;
	int nuf = 0, ptr = 0;
	for(int i=0; i<(N-T); i++){
		byte x = getbit((const long*)src, i);
		encode_symbol(str, low, high, nuf, ptr, x, false);
	}
	for(int i=(N-T); i<N; i++){
		byte x = getbit((const long*)src, i);
		encode_symbol(str, low, high, nuf, ptr, x, true);
	}
	return ptr;
}