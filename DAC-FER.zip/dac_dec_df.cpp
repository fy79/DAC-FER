#include <stdio.h>
#ifdef _IPP
	#include <mathimf.h>
#else
	#include <math.h>
#endif
#include <stdlib.h>
#include <float.h>
#include <iostream>
using namespace std;
#include "share.h"

extern INTERVAL intvl[2], intvlTail[2];
static NODE **branches, *leafBst;
static int nBranches, nCreatedNodes, nDeletedNodes, nFullPasses;
static byte *tailBst, *tail;

//#define CONSTRAINED

#ifdef CONSTRAINED
	bool usedup;
#endif

unsigned *psrc;

/* This routine creates the root node of the decoding tree */
static NODE *create_root(unsigned *str, int M){
	NODE *root = new NODE; nCreatedNodes++;
	root->low = 0; root->high = MASK; root->code = 0; root->ptr = 0;
	for(int i=0; i<ACBITS; i++){
		root->code <<= 1;
		if(root->ptr<M){// get one bit from the bitstream
			root->code |= getbit((const long*)str, root->ptr); root->ptr++;
		}else if(root->ptr==M){// append bit 1 
			root->code |= 1; root->ptr++;
		}else; // append bit 0 
	}
	root->u = (root->code - root->low)/(root->high - root->low + 1.0);
	root->level = 0;
	root->hamdist = 0;
	root->metric = 0.0;
	root->parent = NULL; root->child[0] = NULL; root->child[1] = NULL;
	return root;
}

/* renew the interval after decoding one source symbol */
static void renew_interval(unsigned *str, int M, unsigned &low, unsigned &high, unsigned &code, int &ptr, byte x, bool isTail){
	if(isTail){
		if(x) low += unsigned(ceil((high-low)*intvlTail[1].l + intvlTail[1].l));
		else  high = low + unsigned(ceil((high-low)*intvlTail[0].h + intvlTail[0].h)) - 1;
	}else{
		if(x) low += unsigned(ceil((high-low)*intvl[1].l + intvl[1].l));
		else  high = low + unsigned(ceil((high-low)*intvl[0].h + intvl[0].h)) - 1;
	}

	/* If the MSDigits match, the bits will be shifted out. */
	while(_bittest((const long*)&high,ACBITS-1)==_bittest((const long*)&low,ACBITS-1)){
		low  <<= 1;
		high <<= 1;	high |= 1;
		code <<= 1;
		if(ptr<M){// get a bit from the bitstream 
			code |= getbit((const long*)str,ptr); ptr++;
		}else if(ptr==M){// append bit 1
			code |= 1; ptr++;
		}else; // append bit 0
	}
	low &= MASK, high &= MASK, code &= MASK;

	/* If underflow is threatening, shift out the 2nd MSDigits. */
	while(!_bittest((const long*)&high,ACBITS-2) && _bittest((const long*)&low,ACBITS-2)){
		low  -= QRANGE;	low  <<= 1;
		high -= QRANGE;	high <<= 1;	high |= 1;
		code -= QRANGE;	code <<= 1; 
		if(ptr<M){// get one bit from the bitstream 
			code |= getbit((const long*)str,ptr); ptr++;
		}else if(ptr==M){// append bit 1
			code |= 1; ptr++;
		}else; // append bit 0 
	}
}

/* This routine creates one child node */
static NODE *create_child(NODE *parent, unsigned *str, int M, byte x, byte y, double pc, double *ccs, int nCells, double r){
	NODE *child = new NODE; nCreatedNodes++;
	memcpy(child, parent, 4*sizeof(int));// (low, high, code, ptr)
	renew_interval(str, M, child->low, child->high, child->code, child->ptr, x, false);
	child->level = parent->level + 1;
	child->hamdist = parent->hamdist + (x^y);
	child->u = (child->code - child->low)/(child->high - child->low + 1.0);
	child->metric = (child->hamdist)*log(pc) + ((child->level)-(child->hamdist))*log(1-pc) + (child->level)*r*log(2.0) + log(ccs[int((child->u)*nCells)]);
	child->parent = parent; child->child[0] = NULL; child->child[1] = NULL;
	if(x) parent->child[1] = child; 
	else  parent->child[0] = child;
	return child;
}

static byte get_symbol(double u, bool isTail){
	if(isTail){
		if(u<intvlTail[1].l)	return 0;
		else					return 1;
	}else{
		if(u<intvl[1].l)		return 0;
		else if(u>=intvl[0].h)	return 1;
		else					return 'x';
	}
}

void traceback(unsigned *rec, NODE *leaf){
	NODE *curr = leaf;
	NODE *parent = curr->parent;
	while(parent){
		putbit((long*)rec, parent->level, (curr==(parent->child[1])));
		curr = parent;
		parent = curr->parent;
	}
}

void kill_path(NODE *end){
	NODE *curr = end;
	while(!curr->child[0] && !curr->child[1]){
		NODE *parent = curr->parent;
		if(parent) parent->child[curr==(parent->child[1])] = NULL;
		delete curr; nDeletedNodes++;
		curr = parent;
	}
}

static void delete_tree(NODE *curr){
	if(curr->child[0])	delete_tree(curr->child[0]);
	if(curr->child[1])	delete_tree(curr->child[1]);
	NODE *parent = curr->parent;
	if(parent)	parent->child[curr==(parent->child[1])] = NULL;
	delete curr; nDeletedNodes++;
}

bool normal_pass(NODE *start, unsigned *str, int M, unsigned *side, double pc, int N, int T, double r, double *ccs[], int nCells, int nccs){
	NODE *curr = start;
	for(int i=(start->level); i<(N-T); i++){
		int iccs = min(max(0, (i+1+(nccs-(N-T)))), nccs);
		byte y = getbit((const long*)side, i);
		byte x = get_symbol(curr->u, false);
		if((x==0) || (x==1)){// deterministic node
			if(((curr->hamdist)+(x^y)) < (leafBst->hamdist)){// hopeful
#ifdef CONSTRAINED
				if(nCreatedNodes>=(N-T)*NPATH_MAX){
					usedup = true;
					return false;
				}
#endif
				curr = create_child(curr, str, M, x, y, pc, ccs[iccs], nCells, r);
			}else{// hopeless, early aborted
				kill_path(curr);
				return false;
			}
		}else{// ambiguous node
			if((((curr->hamdist)+y) < (leafBst->hamdist)) && (((curr->hamdist)+(!y)) < (leafBst->hamdist))){// both are hopeful 
				NODE *child[2];
#ifdef CONSTRAINED
				if(nCreatedNodes>=(N-T)*NPATH_MAX){
					usedup = true;
					return false;
				}
#endif
				child[0] = create_child(curr, str, M, 0, y, pc, ccs[iccs], nCells, r);
#ifdef CONSTRAINED
				if(nCreatedNodes>=(N-T)*NPATH_MAX){
					usedup = true;
					return false;
				}
#endif
				child[1] = create_child(curr, str, M, 1, y, pc, ccs[iccs], nCells, r);

				if(i<(N-T-1)){
					curr = child[getbit((const long*)psrc,i)];
				}else{
					int winner = (child[1]->metric) > (child[0]->metric);
					curr = child[winner];					
					branches[nBranches++] = child[!winner];					
				}
			}else{// eithor 0-child path or 1-child path is hopeless
				curr = create_child(curr, str, M, y, y, pc, ccs[iccs], nCells, r);
			}
		}
	}

	NODE *leaf = curr;
	for(int i=(N-T); i<N; i++){
		byte y = getbit((const long*)side, i);
		byte x = get_symbol(leaf->u, true);
		leaf->hamdist += (x^y);
		renew_interval(str, M, leaf->low, leaf->high, leaf->code, leaf->ptr, x, true);
		leaf->u = (leaf->code - leaf->low)/(leaf->high - leaf->low + 1.0);
		tail[i-(N-T)] = x;// fill tail
	}

	if((leaf->hamdist) < leafBst->hamdist){// hopeful
		kill_path(leafBst);
		leafBst = leaf; // update best
		if(T){byte *temp = tailBst; tailBst = tail; tail = temp;}	// swap tail and bstTail
		nFullPasses++;
		return true;	// a full pass	
	}else{// hopeless
		kill_path(leaf);
		return false;
	}
}

void initial_pass(NODE *root, unsigned *str, int M, unsigned *side, double pc, int N, int T, double r, double *ccs[], int nCells, int nccs){
	NODE *curr = root;
	for(int i=0; i<(N-T); i++){
		int iccs = min(max(0, (i+1+(nccs-(N-T)))), nccs);
		byte y = getbit((const long*)side, i);
		byte x = get_symbol(curr->u, false);
		if(x==0 || x==1){// deterministic node
			curr = create_child(curr, str, M, x, y, pc, ccs[iccs], nCells, r);
		}else{// scolus node
			NODE *child[2];
			child[0] = create_child(curr, str, M, 0, y, pc, ccs[iccs], nCells, r);
			child[1] = create_child(curr, str, M, 1, y, pc, ccs[iccs], nCells, r);
			if(i<(N-T-1)){
				curr = child[getbit((const long*)psrc,i)];
			}else{
				int winner = (child[1]->metric) > (child[0]->metric);
				curr = child[winner];
				branches[nBranches++] = child[!winner];
			}
		}
	}

	NODE *leaf = curr;
	for(int i=(N-T); i<N; i++){// fill tailBst
		byte y = getbit((const long*)side, i);
		byte x = get_symbol(leaf->u, true);
		leaf->hamdist += (x^y);
		renew_interval(str, M, leaf->low, leaf->high, leaf->code, leaf->ptr, x, true);
		leaf->u = (leaf->code - leaf->low)/(leaf->high - leaf->low + 1.0);
		tailBst[i-(N-T)] = x;
	}
	leafBst = leaf;
	nFullPasses++;
}

int expand_df(unsigned *rec, unsigned *str, int M, unsigned *side, int N, int T, double pc, double *ccs[], int nCells, int nccs, double r){
#ifdef CONSTRAINED
	usedup = false;
#endif	
	nFullPasses = 0; nCreatedNodes = 0; nDeletedNodes = 0; nBranches = 0; 
	NODE *root = create_root(str, M); 
	branches = new NODE*[(N-T)*NPATH_MAX*100];
	if(T){tailBst = new byte[T]; tail = new byte[T];}
	
	initial_pass(root, str, M, side, pc, N, T, r, ccs, nCells, nccs);
	while(nBranches){
		// pick up the best suspended path from the array
		int k = 0;
		for(int j=1; j<nBranches; j++){
			if((branches[j]->metric) > (branches[k]->metric)){
				k = j;
			}
		}
		NODE *start = branches[k];
		branches[k] = branches[nBranches-1];
		nBranches--;

		// resume the best suspended path
		if(normal_pass(start, str, M, side, pc, N, T, r, ccs, nCells, nccs) && nBranches){
			// compact the tree by pruning hopeless paths accoding to best->hamdist
			for(int j=0; j<nBranches; j++){// forward search
				if((branches[j]->hamdist) >= (leafBst->hamdist)){// the j-th suspended path is hopeless
					kill_path(branches[j]);	// prune the j-th suspended path
					branches[j] = NULL;
					int k = (nBranches-1);	// point to the end node of the last suspended path
					for(; k>j; k--){// backward search
						if((branches[k]->hamdist) >= (leafBst->hamdist)){// the k-th suspended path is hopeless
							kill_path(branches[k]);
							branches[k] = NULL;
						}else{// the k-th suspended path is hopeful
							branches[j] = branches[k];	// branch[j] points to the end node of the k-th suspended path
							branches[k] = NULL;
							break;
						}
					}
					nBranches = k;
				}
			}
		}
#ifdef CONSTRAINED
		if(usedup) break;
#endif
	}
	if(nBranches)	cout<<"Partial Search!"<<endl;

	traceback(rec, leafBst);
	for(int i=(N-T); i<N; i++)	putbit((long*)rec, i, tailBst[i-(N-T)]);
	delete_tree(root);
	delete(branches);
	if(T)  delete tail, tailBst;
	return nCreatedNodes;
}
