#include <stdio.h>
#ifdef _IPP
	#include <mathimf.h>
#else
	#include <math.h>
#endif
#include <stdlib.h>
#include <float.h>
#include <iostream>
using namespace std;
#include "share.h"

extern INTERVAL intvl[2], intvlTail[2];
static NODE *paths[NPATH_MAX];
static int nCreatedNodes, nDeletedNodes;		// number of visited nodes 

static NODE *create_root(unsigned *str, int M){
	NODE *root = new NODE; nCreatedNodes++;
	root->low = 0; root->high = MASK; root->code = 0; root->ptr = 0;
	for(int i=0; i<ACBITS; i++){
		root->code <<= 1;
		if(root->ptr<M){// get one bit from the bitstream
			root->code |= getbit((const long*)str, root->ptr); root->ptr++;
		}else if(root->ptr==M){// append bit 1 
			root->code |= 1; root->ptr++;
		}else; // append bit 0 
	}
	root->u = (root->code - root->low)/(root->high - root->low + 1.0);
	root->level = 0;
	root->hamdist = 0;
	root->metric = 0.0;
	root->parent = NULL; root->child[0] = NULL; root->child[1] = NULL;
	return root;
}

static void renew_interval(unsigned *str, int M, unsigned &low, unsigned &high, unsigned &code, int &ptr, byte x, bool isTail){
	if(isTail){
		if(x) low += unsigned(ceil((high-low)*intvlTail[1].l + intvlTail[1].l));
		else  high = low + unsigned(ceil((high-low)*intvlTail[0].h + intvlTail[0].h)) - 1;
	}else{
		if(x) low += unsigned(ceil((high-low)*intvl[1].l + intvl[1].l));
		else  high = low + unsigned(ceil((high-low)*intvl[0].h + intvl[0].h)) - 1;
	}

	/* If the MSDigits match, the bits will be shifted out. */
	while(_bittest((const long*)&high,ACBITS-1)==_bittest((const long*)&low,ACBITS-1)){
		low  <<= 1;
		high <<= 1;	high |= 1;
		code <<= 1;
		if(ptr<M){// get a bit from the bitstream 
			code |= getbit((const long*)str,ptr); ptr++;
		}else if(ptr==M){// append bit 1
			code |= 1; ptr++;
		}else; // append bit 0
	}
	low &= MASK, high &= MASK, code &= MASK;

	/* If underflow is threatening, shift out the 2nd MSDigits. */
	while(!_bittest((const long*)&high, ACBITS-2) && _bittest((const long*)&low, ACBITS-2)){
		low  -= QRANGE;	low  <<= 1;
		high -= QRANGE;	high <<= 1;	high |= 1;
		code -= QRANGE;	code <<= 1; 
		if(ptr<M){// get one bit from the bitstream 
			code |= getbit((const long*)str,ptr); ptr++;
		}else if(ptr==M){// append bit 1
			code |= 1; ptr++;
		}else; // append bit 0 
	}
}

static NODE *create_child(NODE *parent, unsigned *str, int M, byte x, byte y, double pc, double *ccs, int nCells){
	NODE *child = new NODE; nCreatedNodes++;
	memcpy(child, parent, 4*sizeof(int));// (low, high, code, ptr)
	renew_interval(str, M, child->low, child->high, child->code, child->ptr, x, false);
	child->level = parent->level + 1;
	child->hamdist = parent->hamdist + (x^y);
	child->u = (child->code - child->low)/(child->high - child->low + 1.0);
	child->metric = (child->hamdist)*log(pc) + ((child->level)-(child->hamdist))*log(1-pc) + log(ccs[int((child->u)*nCells)]);
	child->parent = parent; child->child[0] = NULL; child->child[1] = NULL;
	if(x) parent->child[1] = child; 
	else  parent->child[0] = child;
	return child;
}

static byte get_symbol(double u, bool isTail){
	if(isTail){
		if(u<intvlTail[1].l)	return 0;
		else					return 1;
	}else{
		if(u<intvl[1].l)		return 0;
		else if(u>=intvl[0].h)	return 1;
		else					return 'x';
	}
}

static unsigned extend_paths(NODE *paths[], unsigned *str, int M, byte y, double pc, double *ccs, int nCells, int nPaths, int N){
	int nChilds = nPaths;
	for(int j=0; j<nPaths; j++){
		byte x = get_symbol(paths[j]->u, false);
		if(x==0 || x==1){// deterministic branch
			paths[j] = create_child(paths[j], str, M, x, y, pc, ccs, nCells);
		}else{// ambiguous branch
			NODE *child[2];
			child[0] = create_child(paths[j], str, M, 0, y, pc, ccs, nCells);
			child[1] = create_child(paths[j], str, M, 1, y, pc, ccs, nCells);
			if(nChilds<NPATH_MAX){
				paths[j] = child[0];
				paths[nChilds++] = child[1];
			}else{// memory overflow is threatening
				if(j==(nPaths-1)){// the last parent path
					bool winner = ((child[1]->metric)>(child[0]->metric));
					paths[j] = child[winner];
				}else{// other parent paths
					paths[j] = child[0];// replace the j-th parent path with its 0-child path
					paths[nPaths-1] = child[1];// replace the last parent path with the 1-child path of the j-th parent path
					nPaths--;
				}
			}				
		}		
	}
	return nChilds;
}

static int compare(const void *a, const void *b){
	NODE **nodeA = (NODE**)a, **nodeB = (NODE**)b;
	if((*nodeA)->metric > (*nodeB)->metric)			return -1;
	else if((*nodeA)->metric < (*nodeB)->metric)	return 1;
	else											return 0;
}

static NODE *traceback(unsigned *rec, NODE *leaf){
	NODE *curr = leaf;
	NODE *parent = curr->parent;
	while(parent){
		putbit((long*)rec, parent->level, (curr==parent->child[1]));
		curr = parent;
		parent = curr->parent;
	}
	return curr;
}

static void delete_tree(NODE *curr){
	if(curr->child[0])	delete_tree(curr->child[0]);
	if(curr->child[1])	delete_tree(curr->child[1]);
	NODE *parent = curr->parent;
	if(parent)	parent->child[curr==(parent->child[1])] = NULL;
	delete curr; nDeletedNodes++;
}

int expand_bf(unsigned *rec, unsigned *str, int M, unsigned *side, int N, int T, double pc, double *ccs[], int nCells, int nccs){
	nCreatedNodes = 0; nDeletedNodes = 0;
	paths[0] = create_root(str, M);	int nPaths = 1;
	
	// deal with the body
	for(int i=0; i<(N-T); i++){
		byte y = getbit((const long*)side, i);
		int iccs = min(max(0, (i+1+(nccs-(N-T)))), nccs);
		nPaths = extend_paths(paths, str, M, y, pc, ccs[iccs], nCells, nPaths, N);
		qsort(paths, nPaths, sizeof(NODE*), compare);	// sort paths in the descending order of metric
	}

	// deal with the tail
	if(T){
		byte *tailBst = new byte[T], *tail = new byte[T];
		for(int i=(N-T); i<N; i++){// deal with the first path
			byte y = getbit((const long*)side, i);
			byte x = get_symbol(paths[0]->u, true);
			paths[0]->hamdist = paths[0]->hamdist + (x^y);
			renew_interval(str, M, paths[0]->low, paths[0]->high, paths[0]->code, paths[0]->ptr, x, true);
			paths[0]->u = (paths[0]->code - paths[0]->low)/(paths[0]->high - paths[0]->low + 1.0);
			tailBst[i-(N-T)] = x;
		}
		for(int j=1; j<nPaths; j++){// deal with other paths
			for(int i=(N-T); i<N; i++){
				byte y = getbit((const long*)side, i);
				byte x = get_symbol(paths[j]->u, true);
				paths[j]->hamdist = paths[j]->hamdist + (x^y);
				renew_interval(str, M, paths[j]->low,paths[j]->high, paths[j]->code, paths[j]->ptr, x, true);
				paths[j]->u = (paths[j]->code - paths[j]->low)/(paths[j]->high - paths[j]->low + 1.0);
				tail[i-(N-T)] = x;
			}
			if(paths[j]->hamdist < paths[0]->hamdist){// the j-th path is better than the 0-th path
				paths[0] = paths[j];
				byte *temp = tailBst; tailBst = tail; tail = temp; // swap bstTail and tail
			}
		}
		for(int i=(N-T); i<N; i++)	putbit((long*)rec, i, tailBst[i-(N-T)]);	// tail symbols
		delete tail, tailBst;
	}
	
	NODE *root = traceback(rec, paths[0]); // body symbols
	delete_tree(root); 
	return nCreatedNodes;
}