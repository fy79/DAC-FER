#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <float.h>
#include <time.h>
#ifdef _IPP
	#include <mathimf.h>
	#include <ipps.h>
#else
	#include <math.h>
#endif
#include <iostream>
using namespace std;
#include "share.h"

// Macro definitions
#ifdef _IPP
	#define bef(p)	(((p)*(1-(p))==0.0) ? (0.0):(-(p)*log2(p)-(1-(p))*log2(1-(p)))) // binary entropy function
#else
	#define bef(p)	(((p)*(1-(p))==0.0) ? (0.0):((-(p)*log(p)-(1-(p))*log(1-(p)))/log(2.0))) // binary entropy function
#endif
unsigned src[BUFSIZ], side[BUFSIZ], str[BUFSIZ], rec[BUFSIZ];
INTERVAL intvl[2], intvlTail[2];

extern unsigned *psrc;

// initialize intervals
void initialize_intervals(double pb, double alfa){
	intvl[0].l = 0.0;	
	intvl[0].h = pow(1.0-pb, alfa);
	intvl[1].l = 1.0-pow(pb, alfa); 
	intvl[1].h = 1.0;

	intvlTail[0].l = 0.0;	
	intvlTail[0].h = pow(1.0-pb, 1.0);
	intvlTail[1].l = 1.0-pow(pb, 1.0); 
	intvlTail[1].h = 1.0;
}

// count the number of reconstruction errors 
int count_errors(unsigned *rec, unsigned *src, int N){
	int nerrs = 0;
	for(int i=0; i<N; i++)	 nerrs += (getbit((const long*)rec,i)^getbit((const long*)src,i));
	return nerrs;
}

// generate source and side information
void gensrcside(unsigned *src, unsigned *side, int N, double pb, double pc){
	for(int i=0; i<N; i++){
		byte x = (rand()<RAND_MAX*pb);
		putbit((long*)src, i, x);	// put one source symbol
		byte y = x^(rand()<RAND_MAX*pc);
		putbit((long*)side, i, y);	// put one side symbol
	}
}

int config(FILE *fp_out, FILE *fp_ccs, double pc, int seed, int nTries, bool isDF){
	psrc = src;
	
	
	double pb, r, R; // pb: bias prob.; r: overlappaing factor; R: rate
	int N, T;	// N: frame length; T: number of tail symbols
	int nccs, nCells;	// nccs: number of CCS; nCells: number of cells

	// read in source bias probability
	fscanf(fp_ccs, "%lf", &pb);
	if(pb!=0.5){
		cout<<"Only Uniform Binary Source Model is Supported Now!"<<endl;
		return 1;
	}
	// read in code parameters: n, t, R
	double Nlf; fscanf(fp_ccs, "%lf", &Nlf); N = int(Nlf);	// code length
	double Tlf; fscanf(fp_ccs, "%lf", &Tlf); T = int(Tlf);	// code length
	fscanf(fp_ccs, "%lf", &R);
	r = (N*R-T)/(N-T);	// calculate overlapping factor for body
	// read in the ccs for this FLDA code
	double nccslf; fscanf(fp_ccs, "%lf", &nccslf); nccs = int(nccslf);	// code length
	double nCellslf; fscanf(fp_ccs, "%lf", &nCellslf); nCells = int(nCellslf);	// number of cells
	double **ccs = new double*[nccs+1];
	for(int i=0; i<=nccs; i++){
		ccs[i] = new double[nCells];
		for(int j=0; j<nCells; j++){
			fscanf(fp_ccs, "%lf", &ccs[i][j]);
		}
	}

	cout<<"************************ Configurations **********************"<<endl;
	cout<<"Source Bias Prob.: "<<pb<<endl;
	cout<<"Src-SI Cross Prob.: "<<pc<<endl;
	cout<<"Overlap Factor: "<<r<<endl;
	cout<<"Code Rate: "<<R<<endl;
	cout<<"Code Length: "<<N<<endl;
	cout<<"Tail Length: "<<T<<endl;
	cout<<"CCS Number: "<<nccs<<endl;
	cout<<"Cell Number: "<<nCells<<endl;
	cout<<"Initial Seed: "<<seed<<endl;
	cout<<"Try Number: "<<nTries<<endl;
	cout<<"******************** End of Configurations *******************"<<endl<<endl;

	initialize_intervals(pb, r);

	unsigned *pmf_nerrs = new unsigned[N+1];
	memset(pmf_nerrs, 0, (N+1)*sizeof(unsigned));
	unsigned *pmf_epos = new unsigned[N];
	memset(pmf_epos, 0, N*sizeof(unsigned));

	srand(seed); //srand((unsigned)_rdtsc());
	double rate = 0.0, ser = 0.0, fer = 0.0, nCreatedNodes = 0;
	for(int i=0; i<nTries; i++){
		gensrcside(src, side, N, pb, pc);
		int M = compress(str, src, N, T);	rate += M;// str <= src
		if(isDF){
			nCreatedNodes += expand_df(rec, str, M, side, N, T, pc, ccs, nCells, nccs, r); // rec <= (str+side)
		}else{
			nCreatedNodes += expand_bf(rec, str, M, side, N, T, pc, ccs, nCells, nccs); // rec <= (str+side)
		}

		int nerrs = count_errors(rec, src, N);
		fer += (nerrs>0);
		ser += nerrs;

		pmf_nerrs[nerrs]++;
		if(nerrs){
			for(int k=0; k<N; k++){
				pmf_epos[k] += (getbit((const long*)rec,k)^getbit((const long*)src,k));
			}
		}

	}
	rate /= (N*nTries); ser /= (N*nTries); fer /= nTries; nCreatedNodes /= nTries;
	// fprintf(fp_out, "%f\n%f\n%f\n%f\n", rate, ser, fer, nCreatedNodes);

	fprintf(fp_out, "%f\n", fer);

	cout<<"************************ Results **********************"<<endl;
	cout<<"Average Rate: "<<rate<<endl<<"SER: "<<ser<<endl<<"FER: "<<fer<<endl;	
	cout<<"Average Number of Created Nodes: "<<nCreatedNodes<<endl;
	cout<<"******************** End of Results *******************"<<endl<<endl;

	/*for(int i=0; i<=N; i++){
		cout<<pmf_nerrs[i]/(double)nTries<<endl;
		fprintf(fp_out, "%f\n", pmf_nerrs[i]/(double)nTries);
	}
	cout<<endl;*/

	/*for(int i=0; i<N; i++){
		cout<<pmf_epos[i]/(double)nTries<<endl;
		fprintf(fp_out, "%f\n", pmf_epos[i]/(double)nTries);
	}*/

	// free memory
	for(int i=0; i<=nccs; i++)	delete ccs[i];
	delete ccs;
	return 0;
}