#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <float.h>
#include <time.h>
#ifdef _IPP
	#include <mathimf.h>
	#include <ipps.h>
#else
	#include <math.h>
#endif
#include <iostream>
using namespace std;
#include "share.h"

int main(int argc, char *argv[]){
	FILE *fp_out, *fp_ccs;
	int seed = 0, nTries = 1000;

	fp_out = fopen("Results/out/out_64_0_0.5_fer.txt", "wt");
	if(!fp_out){cout<<"Output File Open Fail!"<<endl; return 1;}

	fp_ccs = fopen("Results/ccs/ccs_64_0_0.5.txt", "rt");
	if(!fp_ccs){cout<<"CCS File Open Fail!"<<endl; return 1;}

	config(fp_out, fp_ccs, 0.02, seed, nTries, true);
	fseek(fp_ccs, 0, SEEK_SET);
	config(fp_out, fp_ccs, 0.04, seed, nTries, true);
	fseek(fp_ccs, 0, SEEK_SET);
	config(fp_out, fp_ccs, 0.06, seed, nTries, true);
	fseek(fp_ccs, 0, SEEK_SET);
	config(fp_out, fp_ccs, 0.08, seed, nTries, true);
	fseek(fp_ccs, 0, SEEK_SET);
	config(fp_out, fp_ccs, 0.10, seed, nTries, true);
	fseek(fp_ccs, 0, SEEK_SET);

	fclose(fp_ccs);
	fclose(fp_out);
	getchar();
	return 0;
}