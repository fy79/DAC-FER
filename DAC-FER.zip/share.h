typedef unsigned char byte;
typedef long long int64;
typedef unsigned long long uint64;

// parameters to control the AC codec 
const int ACBITS = 32;
const unsigned HRANGE = (1<<(ACBITS-1));// half of the range
const unsigned QRANGE = (1<<(ACBITS-2));// quarter of the range
const unsigned MASK = ((HRANGE-1)+HRANGE);// range-1

struct NODE{
	unsigned low, high, code;
	int ptr, level, hamdist;
	double u, metric;
	NODE *parent, *child[2];
};
struct INTERVAL{double l; double h;};

#define NPATH_MAX 256

// Macros definitions
#define putbit(buf,i,b)	((b) ? _bittestandset((buf)+((i)>>5), 31-((i)&31)) : _bittestandreset((buf)+((i)>>5), 31-((i)&31)))
#define getbit(buf,i)	_bittest((buf)+((i)>>5), 31-((i)&31))

int compress(unsigned *str, unsigned *src, int N, int T);
int expand_bf(unsigned *rec, unsigned *str, int M, unsigned *side, int N, int T, double pc, double *ccs[], int nCells, int nccs);
int expand_df(unsigned *rec, unsigned *str, int M, unsigned *side, int N, int T, double pc, double *ccs[], int nCells, int nccs, double r);
int config(FILE *fp_results, FILE *fp_ccs, double pc, int seed, int nTries, bool isDF);